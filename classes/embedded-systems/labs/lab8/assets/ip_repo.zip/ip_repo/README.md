---
title: "EECS 41104/51104 Embedded Systems - Vivado Library"
author: "Tendayi Kamucheka (ftendayi@gmail.com)"
date: "11/07/2025"
---

# EECS 41104/51104 Embedded Systems - Vivado Library

![Block Design Example](./block-design.png)

## Overview
This repository contains modified versions of Digilent's Vivado IP, namely, PmodDHB1 and Pmod_Dual_MaxSonar. Additionally, all related IPs and interface definitions required for their integration are included. Please refer back to the original Digilent Library for more details, and updates versions of the IPs, and their associated drivers, and examples.

## Repository Structure
- if/
  - Interface definitions for Pmod ports on Digilent boards.
- ip/
  - PmodDHB1/ : Modified PmodDHB1 IP core.
  - Pmod_Dual_MaxSonar/ : Modified Pmod_Dual_MaxSonar IP core.
  - Additional IPs required for integration.

## Usage
To add these IPs to your Vivado project:
1. Download this repository to your computer.
2. Open your Vivado project.
3. Go to **Settings** → **IP** → **Repository** tab, then add this IP repository folder. Click **Apply** and close.
4. The IP cores are now available to use in your block design.

## License and Attribution
This repository contains modified versions of IP cores originally developed by Digilent, Inc. The original source code is available at https://github.com/Digilent/vivado-library and is licensed under the MIT License.

Copyright (c) Digilent, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
