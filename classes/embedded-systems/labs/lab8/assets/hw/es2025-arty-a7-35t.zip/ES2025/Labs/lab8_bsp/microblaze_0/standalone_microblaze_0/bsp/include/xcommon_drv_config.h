#ifndef XCOMMON_DRV_CONFIG_H_
#define XCOMMON_DRV_CONFIG_H_

#define XPAR_AXI_INTC

#endif