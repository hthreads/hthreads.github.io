# 2025-11-24T20:47:16.913066
import vitis

client = vitis.create_client()
client.set_workspace(path="Labs")

advanced_options = client.create_advanced_options_dict(dt_overlay="0")

platform = client.create_platform_component(name = "lab8_bsp",hw_design = "$COMPONENT_LOCATION/../../base_soc_wrapper.xsa",os = "standalone",cpu = "microblaze_0",domain_name = "standalone_microblaze_0",generate_dtb = False,advanced_options = advanced_options,compiler = "gcc")

comp = client.create_app_component(name="srec_spi_bootloader",platform = "$COMPONENT_LOCATION/../lab8_bsp/export/lab8_bsp/lab8_bsp.xpfm",domain = "standalone_microblaze_0",template = "srec_spi_bootloader")

platform = client.get_component(name="lab8_bsp")
status = platform.build()

comp = client.get_component(name="srec_spi_bootloader")
comp.build()

status = platform.build()

comp.build()

vitis.dispose()

